# Opdrachten voor Mobile & Internet 1, les 2. 

Deze les gaat over de volgende hoofdstukken van de theorie: 

- [HTML Syntax](https://rogiervdl.github.io/HTML-course/02_syntax.html#/)
- [Text](https://rogiervdl.github.io/HTML-course/03_text.html#/)  
- [Links](https://rogiervdl.github.io/HTML-course/04_links.html#/)  
- [Tabellen](https://rogiervdl.github.io/HTML-course/05_tables.html#/)  
- [Objecten](https://rogiervdl.github.io/HTML-course/06_objects.html#/)  

Neem deze vooraf grondig door. Doelstellingen van de oefeningen:

- eenvoudige HTML pagina's correct kunnen aanmaken en valideren
- de voornaamste elementen voor tekst, links en afbeeldingen leren kennen

Begin bij **les02 opgave.pdf**